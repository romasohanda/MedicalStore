package medical.manage.store;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicalStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}

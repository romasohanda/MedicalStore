package medical.manage.store.service;

public interface PurchaseDetailsService {

}

package medical.manage.store;

public class Swagger {

}

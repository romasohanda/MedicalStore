package medical.manage.store.service;

import medical.manage.store.model.Registration;

public interface RegistrationService 
{
public Registration createdata(Registration data);
}


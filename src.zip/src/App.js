import './App.css';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom'
import { history } from './components/login/history'
import { toast } from 'react-toastify';

import HeaderComponent from './components/HeaderComponent';
import FooterComponent from './components/FooterComponent';
import AddOrUpdateManufacturerComponent from './components/AddOrUpdateManufacturerComponent';
import ViewAndDeleteManufacturerComponent from './components/ViewAndDeleteManufacturerComponent';
import AddManufacturerComponent from './components/AddManufacturerComponent';
import UpdateManufacturerComponent from './components/UpdateManufacturerComponent';
import SidebarComponent from './components/SidebarComponent';
import BuyMedicineComponent from './components/BuyMedicineComponent';

import AdminListComponent from './components/AdminListComponent';
import CreateAdminComponent from './components/CreateAdminComponent';
import ViewAdminDetails from './components/ViewAdminDetails';
import UpdateAdminDetailsComponent from './components/UpdateAdminDetailsComponent'

import ViewStock from './components/ViewStock';
import AddStock from './components/AddStock';
import Home from './components/Home'
import UpdateStock from './components/UpdateStock';

import welcome from './components/login/welcome'
import Register from './components/registration/registration';
import Login from './components/login/login'

toast.configure();

function App() {
return (
<div>
<Router history={history} forceRefresh={true} >
      <HeaderComponent />
      {/* <SidebarComponent/> */}
      <Switch>
      {/* <Route path = "/add-manufacturer/:id" component = {AddOrUpdateManufacturerComponent}></Route> */}
      <Route path = "/view-manufacturer" component = {ViewAndDeleteManufacturerComponent}></Route>
      <Route path="/add-manufacturer" component={AddManufacturerComponent}></Route>
      <Route path="/update-manufacturer" component={UpdateManufacturerComponent}></Route>
      <Route path="/buy-medicine" component={BuyMedicineComponent}></Route>

      <Route path="/admin-list" component={AdminListComponent}></Route>
      <Route path="/registration" component={CreateAdminComponent}></Route>
      <Route path="/viewall-adminDetails/:adminId" component={ViewAdminDetails}></Route> 
      <Route path="/update-adminDetails/:adminId" component={UpdateAdminDetailsComponent}></Route>

      <Route path="/listOfStock"><ViewStock></ViewStock></Route>
      <Route path="/add" component={AddStock}></Route>
      <Route exact path="/"><Home></Home></Route>
      <Route path="/updateStock" component={UpdateStock}></Route> 

      <Route path="/login" component={Login}></Route>
      <Route path="/register" component={Register}></Route>
      <Route path="/welcome" component={welcome}></Route>
      </Switch>
      {/* <FooterComponent/> */}
      </Router>
    </div>
  );
}

export default App;
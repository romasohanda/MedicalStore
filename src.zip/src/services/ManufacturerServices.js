import axios from 'axios';

const MANUFACTURER_API_BASE_URL = "http://localhost:8000/api/v1/medicalstore/manufacturer";
const MEDICINE_API_BASE_URL= "http://localhost:8000/api/v1/medicalstore/medicines"

class ManufacturerServices {

    getManufacturers(){
        return axios.get(MANUFACTURER_API_BASE_URL + '/view_all_manufacturers');
    }

    addManufacturer(manufacturer){
        return axios.post(MANUFACTURER_API_BASE_URL + '/add_manufacturer', manufacturer);
    }

    getManufacturerById(id){
        return axios.get(MANUFACTURER_API_BASE_URL + '/get_manufacturer_by_id/' + id);
    }

    updateManufacturer(manufacturer){
        return axios.put(MANUFACTURER_API_BASE_URL + '/update_manufacturer', manufacturer);
    }

    deleteManufacturer(manufacturerId){
        return axios.delete(MANUFACTURER_API_BASE_URL + '/delete_manufacturer/' + manufacturerId);
    }

    addMedicine(medicine){
        return axios.post(MEDICINE_API_BASE_URL + '/add', medicine);
    }


}

export default new ManufacturerServices()
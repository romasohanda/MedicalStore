import axios from 'axios'
const Admin_API_Details="http://localhost:8000/api/v1/medicalstore/adminDetails"
const DELETE_API_DETAILS="http://localhost:8000/api/v1/medicalstore/adminDetails/deleteadmin"
const CREATE_API_DETAILS="http://localhost:8000/api/v1/medicalstore/adminDetails/registration"

class AdminToAdminServices{
    getAllAdminDetails(){
        return axios.get(Admin_API_Details);
    }
    createNewAdmin(newAdmin){
       
        return axios.post(CREATE_API_DETAILS, newAdmin);
    }
    getAdminDetailsById(adminId){
        return axios.get(Admin_API_Details + '/' + adminId)
    }
    deleteAdminByadminId(adminId)
    {
        return axios.delete(DELETE_API_DETAILS + '/' + adminId);
    }
    updateOrSaveAdminDetails(updateAdminDetails,adminId){
return axios.put(Admin_API_Details + '/updateProfile/' + adminId, updateAdminDetails)
    }
    
}
export default new AdminToAdminServices;
import React, { Component } from 'react';
import ManufacturerServices from '../services/ManufacturerServices';

import pic from '../images/medical-plus.svg';
import best from '../images/best.png'
import adminimg from '../images/admin login.png';
import customerlogin from '../images/customer login.png';

import logo from '../images/logo medical.png';

class BuyMedicineComponent extends Component {
    constructor(props){
        super(props)
        this.state={
            medicineName:'',
            quantity:''
        }

        this.changeNameHandler=this.changeNameHandler.bind(this);
        this.changeQuantityHandler=this.changeQuantityHandler.bind(this);
        this.save=this.save.bind(this);
    }

    changeNameHandler=(event)=>{
        this.setState({medicineName: event.target.value});
    }

    changeQuantityHandler=(event)=>{
        this.setState({quantity: event.target.value});
    }

    cancel(){
        this.props.history.push('/view-manufacturer');
    }

    save=(e)=>{
        e.preventDefault();
        let med={medicineName: this.state.medicineName, quantity: this.state.quantity};
        console.log('med =>' + JSON.stringify(med));

        ManufacturerServices.addMedicine(med).then(res =>{
            this.props.history.push('/view-manufacturer');
        })
    }

    render() {
        return (
            <div>
                <nav className="navbar navbar-expand-lg navbar-light bg-light fixed-top">
                    <div className="container-fluid">
                        <div className="collapse navbar-collapse" id="navbarNav">
                            <ul className="navbar-nav">

                                <li className="nav-item">
                                    <img src={logo} style={{height:'50px', width:'190px'}}/>
                                </li>

                                <li className="nav-item" style={{marginLeft:'5px'}}>
                                    <a className="nav-link" href="/" to="/">Home</a>
                                </li>
                                
                                <li className="nav-item">
                                    <a className="nav-link" to="/listOfStock">Contact</a>
                                </li>
{/* 
                                <li className="nav-item" style={{float:'right', marginLeft:'800px', padding:'5px', height:'30px', width:'30px'}}>
                                    <img src={customerlogin} /> &nbsp;
                                </li>
                                <li className="nav-item" style={{float:'right'}}>    
                                    <a className="nav-link" to="">Logout</a>
                                </li> */}
                            </ul>
                        </div>
                    </div>
                </nav>
                <div class="sidenav">
                    <a href="/"> Home</a>
                    <a href="/admin-list">Admins</a>
                    <a href="/view-manufacturer">Manufacturers</a>
                    <a href="/listOfStock">View Stock</a>
                    <a href="/buy-medicine">Medicines</a>
                    <a href="/add-manufacturer">Add Manufacturers</a>
                    <a href="/registration">Add Admin</a>
                    <a href="/add">Add Stock</a>
                </div>

            <div id="back2"><br/><br/><br/><br/><br/><br/>
                <div id="form" className="container">
                    <div className="row">
                        <div id="buy" className="card col-md-6 offset-md-3"><br/>
                            <h2 className="text-center ">Add purchased Medicines</h2>
                            <div className="card-body">
                                <form>
                                    <div className="form-group">
                                    <label>Medicine Name</label>
                                        <input placeholder="Enter medicine name" 
                                        name="name" className="form-control" value={this.state.medicineName} 
                                        onChange={this.changeNameHandler}></input><br></br>
                                        
                                        <label>Quantity</label>
                                        <input placeholder="Enter quantity purchased" 
                                        name="name" className="form-control" value={this.state.quantity} 
                                        onChange={this.changeQuantityHandler}></input><br></br>

                                    </div>
                                    <button className="btn btn-primary" onClick={this.save}>Save</button>
                                    <button style={{marginLeft: "10px"}} className="btn btn-danger" onClick={this.cancel.bind(this)}>Cancel</button>
                                </form>
                            </div>
                        </div>
                    </div><br/><br/><br/><br/>
                </div>
            </div>
            </div>
        );
    }
}

export default BuyMedicineComponent;
import React, {Component} from 'react'
import AdminToAdminServices from '../services/AdminToAdminServices';
import backgr from '../images/backgr.jpeg';
import pic from '../images/medical-plus.svg';
import best from '../images/best.png'
import adminimg from '../images/admin login.png';
import customerlogin from '../images/customer login.png';

import logo from '../images/logo medical.png';

class ViewAdminDetails extends Component{
      constructor(props){
          super(props)
          this.state={
              adminId:this.props.match.params.adminId,
             adminDetails:{}
          }
          this.adminList=this.adminList.bind(this);
         
        }
        adminList(){
            this.props.history.push('/admin-list');
        }
        componentDidMount(){
            AdminToAdminServices.getAdminDetailsById(this.state.adminId).then(res =>{
                this.setState({adminDetails:res.data})
            })
        }
        
        render(){
            return(
                <div>
                    <nav className="navbar navbar-expand-lg navbar-light bg-light fixed-top">
                    <div className="container-fluid">
                        <div className="collapse navbar-collapse" id="navbarNav">
                            <ul className="navbar-nav">

                                <li className="nav-item">
                                    <img src={logo} style={{height:'50px', width:'190px'}}/>
                                </li>

                                <li className="nav-item" style={{marginLeft:'5px'}}>
                                    <a className="nav-link" href="/" to="/">Home</a>
                                </li>
                                
                                <li className="nav-item">
                                    <a className="nav-link">Contact</a>
                                </li>
{/* 
                                <li className="nav-item" style={{float:'right', marginLeft:'800px', padding:'5px', height:'30px', width:'30px'}}>
                                    <img src={customerlogin} /> &nbsp;
                                </li>
                                <li className="nav-item" style={{float:'right'}}>    
                                    <a className="nav-link" to="">Logout</a>
                                </li> */}
                            </ul>
                        </div>
                    </div>
                </nav>

                <div class="sidenav">
                    <a href="/"> Home</a>
                    <a href="/admin-list">Admins</a>
                    <a href="/view-manufacturer">Manufacturers</a>
                    <a href="/listOfStock">View Stock</a>
                    {/* <a href="/buy-medicine">Medicines</a> */}
                    <a href="/add-manufacturer">Add Manufacturers</a>
                    <a href="/registration">Add Admin</a>
                    <a href="/add">Add Stock</a>
                </div>

                <div style={{backgroundImage:`url(${backgr})`,backgroundRepeat: "no-repeat", height:"1000px", width:"100%"}}>
                    <div style={{paddingLeft:"500px",paddingTop:"100px"}} >
                    <h2 >View Employee Page</h2>
<div style={{paddingLeft:"10px",paddingTop:"40px"}}>
    <div className="row" >
        <label style={{paddingRight:"10px"}} className="text-center">Admin Name:</label>
    
        <div>{this.state.adminDetails.adminName}</div>
        </div>
        <div className="row">
        <label style={{paddingRight:"10px"}}>Admin Age: </label>
        <div>{this.state.adminDetails.adminAge}</div>
        </div>
        
        <div className="row">
        <label style={{paddingRight:"10px"}}>Admin Phone Number: </label>
        <div>{this.state.adminDetails.adminPhoneNum}</div>
        </div>
        
        <div className="row">
            <button style={{marginTop:"20px"}}onClick={this.adminList} className="btn btn-danger">OK</button>
        </div>
      
      
</div>
                    </div>
                   
                </div>
                </div>
            )
        }
    };
        export default ViewAdminDetails;
          /*<div className="row">
            <button onClick={this.changeEmail(this.state.id)} className="btn btn-danger">Change </button>
        </div>*/
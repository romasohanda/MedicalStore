import React, { Component } from 'react';
import ManufacturerServices from '../services/ManufacturerServices';

import pic from '../images/medical-plus.svg';
import best from '../images/best.png'
import adminimg from '../images/admin login.png';
import customerlogin from '../images/customer login.png';

import logo from '../images/logo medical.png';

class AddManufacturerComponent extends Component {
    constructor(props){
        super(props)
        this.state={
            manufacturerName:'',
            mfgLicence:'',
            address:''
        }
        this.changeNameHandler=this.changeNameHandler.bind(this);
        this.changeLicenceHandler=this.changeLicenceHandler.bind(this);
        this.changeAddressHandler=this.changeAddressHandler.bind(this);
        this.saveManufacturer=this.saveManufacturer.bind(this);
    }

    changeNameHandler=(event)=>{
        this.setState({manufacturerName: event.target.value});
    }

    changeLicenceHandler=(event)=>{
        this.setState({mfgLicence: event.target.value});
    }

    changeAddressHandler=(event)=>{
        this.setState({address: event.target.value});
    }

    cancel(){
        this.props.history.push('/view-manufacturer');
    }

    saveManufacturer = (e) => {
        e.preventDefault();
        let manu = {
            manufacturerName: this.state.manufacturerName,
            mfgLicence: this.state.mfgLicence,
            address: this.state.address
           
        }
        const checkValid = this.validate();
        console.log('manu=>'+JSON.stringify(manu));
        if (checkValid) {
            ManufacturerServices.addManufacturer(manu).then(response => {
                alert('Manufacturer added successfully')
            this.props.history.push('/view-manufacturer');  
        });
    }
    else {
        alert("Remove errors and then submit");
    }
    }

    validate = () => {
        let nameError = "";
        let licenceError = "";
       

     if (!this.state.manufacturerName.match("[a-zA-Z]") || this.state.manufacturerName.length < 3) {
           nameError = "Please enter valid Name";
       }
     if (!this.state.mfgLicence.match("[A-Za-z]{3}[0-9]{7}")) {
          licenceError = "Please Enter valid Licence Number";
         }

        if (nameError || licenceError) {
            this.setState({
                nameError, licenceError
            });
            return false;
        }
        return true;
    };

    render() {
        return (
            <div>
                <nav className="navbar navbar-expand-lg navbar-light bg-light fixed-top">
                    <div className="container-fluid">
                        <div className="collapse navbar-collapse" id="navbarNav">
                            <ul className="navbar-nav">

                                <li className="nav-item">
                                    <img src={logo} style={{height:'50px', width:'190px'}}/>
                                </li>

                                <li className="nav-item" style={{marginLeft:'5px'}}>
                                    <a className="nav-link" href="/" to="/">Home</a>
                                </li>
                                
                                <li className="nav-item">
                                    <a className="nav-link" to="/listOfStock">Contact</a>
                                </li>
{/* 
                                <li className="nav-item" style={{float:'right', marginLeft:'800px', padding:'5px', height:'30px', width:'30px'}}>
                                    <img src={customerlogin} /> &nbsp;
                                </li>
                                <li className="nav-item" style={{float:'right'}}>    
                                    <a className="nav-link" to="">Logout</a>
                                </li> */}
                            </ul>
                        </div>
                    </div>
                </nav>

                <div class="sidenav">
                    <a href="/"> Home</a>
                    <a href="/admin-list">Admins</a>
                    <a href="/view-manufacturer">Manufacturers</a>
                    <a href="/listOfStock">View Stock</a>
                    {/* <a href="/buy-medicine">Medicines</a> */}
                    <a href="/add-manufacturer">Add Manufacturers</a>
                    <a href="/registration">Add Admin</a>
                    <a href="/add">Add Stock</a>
                </div>

            <div id="back"><br/><br/><br/><br/><br/>
                <div id="form" className="container">
                    <div className="row">
                        <div className="card col-md-6 offset-md-3">
                            <h2 className="text-center ">Add Manufacturer</h2>
                            <div className="card-body">
                                <form>
                                    <div className="form-group">
                                        <label>Manufacturer's Name</label>
                                        <input placeholder="Enter Name of the Manufacturer" 
                                        name="name" className="form-control" value={this.state.manufacturerName} 
                                        onChange={this.changeNameHandler} required="required"></input>
                                        <div style={{ color: "red" }}>{this.state.nameError}</div><br></br>
                                        
                                        <label>Manufacturer's mfg Licence number</label>
                                        <input placeholder="Enter mfg licence number" 
                                        name="name" className="form-control" value={this.state.mfgLicence} 
                                        onChange={this.changeLicenceHandler} required="required"></input>
                                        <div style={{ color: "red" }}>{this.state.licenceError}</div><br></br>
                                        
                                        <label>Manufacturer's address</label>
                                        <input placeholder="Enter address of the Manufacturer" 
                                        name="name" className="form-control" value={this.state.address} 
                                        onChange={this.changeAddressHandler} required="required"></input>
                                    </div>
                                    <button className="btn btn-primary" onClick={this.saveManufacturer}>Save</button>
                                    <button style={{marginLeft: "10px"}} className="btn btn-danger" onClick={this.cancel.bind(this)}>Cancel</button>
                                </form>
                            </div>
                        </div>
                    </div><br/><br/><br/>
                </div>
            </div>
            </div>
        );
    }
}

export default AddManufacturerComponent;
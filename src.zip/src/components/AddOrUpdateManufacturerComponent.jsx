import React, { Component } from 'react'
import ManufacturerServices from '../services/ManufacturerServices';

class AddOrUpdateManufacturerComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            manufacturerId: this.props.match.params.manufacturerId,
            manufacturerName: '',
            mfgLicence: '',
            address: ''
        }
        this.changeManufacturerNameHandler = this.changeManufacturerNameHandler.bind(this);
        this.changeMfgLicenceHandler = this.changeMfgLicenceHandler.bind(this);
        this.changeAddressHandler = this.changeAddressHandler.bind(this);
        this.saveOrUpdateManufacturer = this.saveOrUpdateManufacturer.bind(this);
    }

    componentDidMount(){

        if(this.state.manufacturerId === '_add'){
            return
        }else{
            ManufacturerServices.getManufacturerById(this.state.manufacturerId).then( (res) =>{
                let manufacturers = res.data;
                this.setState({manufacturerName: manufacturers.manufacturerName,
                    mfgLicence: manufacturers.mfgLicence,
                    address : manufacturers.address
                });
            });
        }        
    }
    saveOrUpdateManufacturer = (e) => {
        e.preventDefault();
        let manufacturer = {manufacturerName: this.state.manufacturerName, mfgLicence: this.state.mfgLicence, address: this.state.address};
        console.log('manufacturer => ' + JSON.stringify(manufacturer));

        if(this.state.manufacturerId === '_add'){
            ManufacturerServices.addManufacturer(manufacturer).then(res =>{
                this.props.history.push('/add-manufacturer');
            });
        }
        else
        {
            ManufacturerServices.updateManufacturer(this.state.manufacturerId,manufacturer).then( res => {
                this.props.history.push('/add-manufacturer');
            });
        }
    }
    
    changeManufacturerNameHandler= (event) => {
        this.setState({manufacturerName: event.target.value});
    }

    changeMfgLicenceHandler= (event) => {
        this.setState({mfgLicence: event.target.value});
    }

    changeAddressHandler= (event) => {
        this.setState({address: event.target.value});
    }

    cancel(){
        this.props.history.push('/view-manufacturer');
    }

    getTitle(){
        if(this.state.manufacturerId === '_add'){
            return <h3 className="text-center">Add Manufacturer</h3>
        }
        else{
            return <h3 className="text-center">Update Manufacturer</h3>
        }
    }
    render() {
        return (
            <div>
                <br></br>
                   <div className = "container">
                        <div className = "row">
                            <div className = "card col-md-6 offset-md-3 offset-md-3">
                                {
                                    this.getTitle()
                                }
                                <div className = "card-body">
                                    <form>
                                        <div className = "form-group">
                                            <label> Manufacturer Name: </label>
                                            <input placeholder="Manufacturer Name" name="manufacturerName" className="form-control" 
                                                value={this.state.manufacturerName} onChange={this.changeManufacturerNameHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> mfg Licence: </label>
                                            <input placeholder="mfg Licence" name="mfgLicence" className="form-control" 
                                                value={this.state.mfgLicence} onChange={this.changeMfgLicenceHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Address: </label>
                                            <input placeholder="Address" name="address" className="form-control" 
                                                value={this.state.address} onChange={this.changeAddressHandler}/>
                                        </div>

                                        <button className="btn btn-primary" onClick={this.saveOrUpdateManufacturer}>Save</button>
                                        <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                                    </form>
                                </div>
                            </div>
                        </div>

                   </div>
            </div>
        )
    }
}

export default AddOrUpdateManufacturerComponent
import React, {Component} from 'react'
import AdminToAdminServices from '../services/AdminToAdminServices'

import pic from '../images/medical-plus.svg';
import best from '../images/best.png'
import adminimg from '../images/admin login.png';
import customerlogin from '../images/customer login.png';

import logo from '../images/logo medical.png';

class AdminListComponent extends Component{
      constructor(props){
          super(props)
          this.state={
adminDetails:[]
          };
     this.createAdmin=this.createAdmin.bind(this);
     this.updateAdminDetails=this.updateAdminDetails.bind(this);
this.deleteAdmin=this.deleteAdmin.bind(this);
this.viewAllAdminDetails=this.viewAllAdminDetails.bind(this);
      }
      viewAllAdminDetails(adminId){
        this.props.history.push(`/viewall-adminDetails/${adminId}`);
      }
      componentDidMount(){
          AdminToAdminServices.getAllAdminDetails().then((res) =>{
              this.setState({adminDetails:res.data});
          });
      }
      createAdmin(){
          this.props.history.push('/registration');
      }
      updateAdminDetails(adminId){
          this.props.history.push(`/update-adminDetails/${adminId}`);
      }
      deleteAdmin(adminId){
AdminToAdminServices.deleteAdminByadminId(adminId).then(res =>{
    this.setState({adminDetails: this.state.adminDetails.filter(adminDetail => adminDetail.adminId !== adminId)});
});
      }
      
      render(){
          return(
              <div>
                  <nav className="navbar navbar-expand-lg navbar-light bg-light fixed-top">
                    <div className="container-fluid">
                        <div className="collapse navbar-collapse" id="navbarNav">
                            <ul className="navbar-nav">

                                <li className="nav-item">
                                    <img src={logo} style={{height:'50px', width:'190px'}}/>
                                </li>

                                <li className="nav-item" style={{marginLeft:'5px'}}>
                                    <a className="nav-link" href="/" to="/">Home</a>
                                </li>
                                
                                <li className="nav-item">
                                    <a className="nav-link">Contact</a>
                                </li>
{/* 
                                <li className="nav-item" style={{float:'right', marginLeft:'800px', padding:'5px', height:'30px', width:'30px'}}>
                                    <img src={customerlogin} /> &nbsp;
                                </li>
                                <li className="nav-item" style={{float:'right'}}>    
                                    <a className="nav-link" to="">Logout</a>
                                </li> */}
                            </ul>
                        </div>
                    </div>
                </nav>

                <div class="sidenav">
                    <a href="/"> Home</a>
                    <a href="/admin-list">Admins</a>
                    <a href="/view-manufacturer">Manufacturers</a>
                    <a href="/listOfStock">View Stock</a>
                    {/* <a href="/buy-medicine">Medicines</a> */}
                    <a href="/add-manufacturer">Add Manufacturers</a>
                    <a href="/registration">Add Admin</a>
                    <a href="/add">Add Stock</a>
                </div>

<div className="container" style={{marginLeft:"70px"}}>


<h2 id="list" style={{paddingTop:"80px"}}className="text-center">Admin List</h2>
{/* <div style={{marginBottom:"10px"}}className="row">
    <button className="btn btn-primary" onClick={this.createAdmin}>Create Admin</button>
</div> */}
<div className="row">
    <table className="table table-striped table-bordered">
<thead>
    <tr>
        <th>Admin Name</th>
        <th>Admin Age
        </th>
        <th>Admin Joining Date</th>
        <th>Admin Phone Numbers</th>
        <th style={{textAlign:"center"}}>Actions</th>
    </tr>
</thead>
<tbody>
    {
        this.state.adminDetails.map(
            adminDetail=>
                <tr key={adminDetail.adminId}>
                    <td>{adminDetail.adminName}</td>
                    <td>{adminDetail.adminAge}</td>
                    <td>{adminDetail.adminJoiningDate}</td>
                    <td>{adminDetail.adminPhoneNum}</td>

                    <td>
                        <button onClick={() => this.updateAdminDetails(adminDetail.adminId)} style={{marginLeft:"50px"}} className="btn btn-info">Update</button>
                        <button style={{marginLeft:"10px"}} onClick={() => this.deleteAdmin(adminDetail.adminId)} className="btn btn-danger">Delete</button>
                        <button style={{marginLeft:"10px"}} onClick={() => this.viewAllAdminDetails(adminDetail.adminId)} className="btn btn-info">View</button>
                       
                    </td>

                </tr>
            
        )
    }
</tbody>
    </table>
</div>
</div>
</div>
          )
      }
}
export default AdminListComponent;
import React, { Component } from 'react';

class SidebarComponent extends Component {

    render() {
        return (
                <div class="sidenav">
                    <a href=""> Home</a>
                    <a href="/admin-list">Admins</a>
                    <a href="/view-manufacturer">Manufacturers</a>
                    {/* <a href="/buy-medicine/:manufacturerId">Add Medicines</a> */}
                    <a href="/add-manufacturer">Add manufacturer</a>
                    <a href="/registration">Add Admin</a>
                    <a href="/add">Add Stock</a>
                </div>
        );
    }
}

export default SidebarComponent;
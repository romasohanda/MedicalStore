import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Link, Route } from 'react-router-dom';
import axios from 'axios';

import AddStock from './AddStock';


import pic from '../images/medical-plus.svg'
import edit from '../images/edit.png'
import bin from '../images/bin.png'
import plus from '../images/plus3.png'
import best from '../images/best.png'
import adminimg from '../images/admin login.png';
import customerlogin from '../images/customer login.png';
import addmanufacturer from '../images/addmanufacturer.png'
import plusmanufacturer from '../images/plusmanufacturer.png'
import medicine from '../images/medicine.png'
import stockimg from '../images/stock.png'
import admins from '../images/admins.png'
import homeicon from '../images/homeicon.png'
import logo from '../images/logo medical.png';
import UpdateStock from './UpdateStock';

class ViewStock extends Component {
    
    constructor(props){
        super(props)

        this.state = {
            stock: [],
            errorMsg: ''
        }
    }

    componentDidMount() {
        axios.get('http://localhost:8000/api/v1/medicalstore/stocks/')
            .then((response) => {
                console.log(response);
                this.setState({stock: response.data})
        
            })
            .catch(error => {
                console.error(error);
                this.setState({errorMsg: 'Error Retrieving Data!'})
            })

           
            
    }

    delete(stockId){
        axios.delete(`http://localhost:8000/api/v1/medicalstore/stocks/delete/${stockId}`)
            .then((response) => {
                console.log(response);
                alert('Successfully Deleted!')
                window.location.reload(true);
                
            })
            .catch(error => {
                console.error(error);
                this.setState({errorMsg: 'Error Deleting Data!'})
            })  
        
    }
    
    

    render() {
        const{ stock, errorMsg } = this.state
        return(
            <div>
                
                {/* <div class="sidenav" style={{width:'150px',background: 'linear-gradient(111.14deg, rgba(255, 255, 255, 0.51) 3.08%, #76dbca 97.5%)', backdropFilter:'blur(10000%)'}}>
                    <a href="/" style={{fontSize:'13px', marginTop:'3px'}}> 
                    <img src={homeicon} style={{height:'30px', width:'30px', marginLeft:'40px'}}/><br/>
                    <div style={{fontSize:'13px', marginTop:'3px', marginLeft:'35px', color:'#276A7B'}}>Home</div></a>
                    <a href="/admin-list" style={{fontSize:'13px', marginTop:'3px'}}>
                    <img src={admins} style={{height:'30px', width:'30px', marginLeft:'40px'}}/><br/>
                    <div style={{fontSize:'13px', marginTop:'3px', marginLeft:'35px', color:'#276A7B'}}>Admins</div></a>
                    <a href="/view-manufacturer" style={{fontSize:'13px', marginTop:'3px'}}>
                    <img src={addmanufacturer} style={{height:'30px', width:'30px', marginLeft:'40px'}}/><br/>
                    <div style={{fontSize:'13px', marginTop:'3px', marginLeft:'20px', color:'#276A7B'}}>Manufacturers</div></a>
                    <a href="/listOfStock" style={{fontSize:'13px', marginTop:'3px'}}>
                    <img src={stockimg} style={{height:'30px', width:'30px', marginLeft:'40px'}}/><br/>
                    <div style={{fontSize:'13px', marginTop:'3px', marginLeft:'30px', color:'#276A7B'}}>View Stock</div></a>
                    <a href="/buy-medicine/:manufacturerId" style={{fontSize:'13px', marginTop:'3px'}}>
                    <img src={medicine} style={{height:'45px', width:'45px', marginLeft:'30px'}}/><br/>
                    <div style={{fontSize:'13px', marginTop:'3px', marginLeft:'30px', color:'#276A7B'}}>Medicine</div></a>
                    <a href="/add-manufacturer" style={{fontSize:'13px', marginTop:'3px'}}>
                    <img src={plusmanufacturer} style={{height:'20px', width:'20px', marginLeft:'20px'}}/>
                    <img src={addmanufacturer} style={{height:'30px', width:'30px'}}/><br/>
                    <div style={{fontSize:'13px', marginTop:'3px', color:'#276A7B'}}>Add Manufacturer</div></a>
                </div> */}

                <div class="sidenav">
                     <a href="/"> Home</a>
                     <a href="/admin-list">Admins</a>
                     <a href="/view-manufacturer">Manufacturers</a>
                     <a href="/listOfStock">View Stock</a>
                     {/* <a href="/buy-medicine">Medicines</a> */}
                     <a href="/add-manufacturer">Add Manufacturers</a>
                     <a href="/registration">Add Admin</a>
                     <a href="/add">Add Stock</a>
                 </div>

                <div style={{marginTop:"70px", marginLeft:"300px"}}>
                <div class='container my-2' style={{backgroundColor:'', height:'80px', width:'100%', padding:'20px', borderRadius:'20px', verticalAlign:'middle'}}>
                    <Link class='rounded-pill' style={{fontSize:'20px', float:'right', color:'#666565', marginRight:'15px', height:'50px', width:'90px', backgroundColor:'#3156A7', border:'none', color:'white'}} to="/updateStock" >
                    <img src={edit} style={{height:'30px', width:'30px', marginTop:'10px', marginLeft:'30px'}}/>
                    </Link> 
                    <Route exact path="/updateStock">
                        <UpdateStock></UpdateStock>
                    </Route>
                    <Link class='rounded-pill' style={{fontSize:'20px', float:'left', color:'#666565', marginLeft:'15px', height:'50px', width:'90px', backgroundColor:'#3156A7', border:'none', color:'white'}} to="/add" >
                    <img src={plus} style={{height:'30px', width:'30px', marginTop:'10px', marginLeft:'30px'}}/>
                    </Link> 
                    <Route exact path="/add">
                        <AddStock></AddStock>
                    </Route>
                </div>


                {   stock.length?
                    stock.map( s =>
                <div class="card my-2 mx-3" style={{borderLeft:'5px solid #276A7B', borderRadius:'25px'}}>
                    <div class="card-body">
                    <img class="card-img-top" src={pic} alt="medical plus sign" style={{height:'100px', width:'100px', marginTop:'5px', marginBottom:'5px', float:'left'}}/>
                  <div class='container'>
                  <div class='row'>
                        <div class='col-7'>
                            <div class='row'>
                                <div style={{color:'#276A7B', marginLeft:'30px', fontFamily:'', fontSize:'50px', float:'left'}}>{s.medicineName} </div>
                            </div>
                            <div class='row'>
                                <div style={{color:'#999999', marginLeft:'30px', fontFamily:'', fontSize:'20px', float:'left', marginTop:'20px'}}> {s.sold} sold&nbsp; &nbsp; | &nbsp; &nbsp; {s.inStock}&nbsp;left in stock</div>
                            </div>
                        </div>
                        <div class='col-5'>
                            <div class='row'>
                            <div class='col'>
                                <button class='rounded-pill' style={{ fontFamily:'', fontSize:'20px', border:'none', backgroundColor:'#36A592', height:'80px', width:'60px', marginTop:'15px', marginLeft:'-40px'}}>
                                <div style={{color:'white', fontStyle:'bold', fontSize:'20px'}}><strong>{s.stockId}</strong></div>   
                                </button>  
                                <button class='rounded-pill' style={{ fontFamily:'', fontSize:'20px', border:'none', backgroundColor:'#EC275F', height:'80px', width:'60px', marginTop:'15px', marginLeft:'5px'}} onClick={this.delete.bind(this,s.stockId)}>
                                <img src={bin} style={{height:'30px', width:'30px'}}/>    
                                </button>      
                            </div>
                            <div class='col'>
                                <div style={{color:'#ed9e4a', fontFamily:'', fontSize:'50px', float:'right', marginTop:'15px'}}>{s.costEach}&nbsp;INR.</div>        
                            </div>
                            </div>
                        </div>
                  </div>
                    </div>
                    </div>
                    </div>
                    ):
                    null
                    }
                    <div>
                        { errorMsg.length? <div>{errorMsg}</div>: null}
                    </div>
                    </div>
            </div>
        )
    }
}

export default ViewStock

// import React, { Component } from 'react';
// import { BrowserRouter as Router, Switch, Link, Route } from 'react-router-dom';
// import axios from 'axios';

// import AddStock from './AddStock';

// import pic from '../images/medical-plus.svg';
// import best from '../images/best.png'
// import adminimg from '../images/admin login.png';
// import customerlogin from '../images/customer login.png';

// import logo from '../images/logo medical.png';

// class ViewStock extends Component {
    
//     constructor(props){
//         super(props)

//         this.state = {
//             stock: [],
//             medicine: [],
//             errorMsg: ''
//         }
//     }

//     componentDidMount() {
//         axios.get('http://localhost:8080/api/v1/medicalstore/stocks/')
//             .then((response) => {
//                 console.log(response);
//                 this.setState({stock: response.data})
        
//             })
//             .catch(error => {
//                 console.error(error);
//                 this.setState({errorMsg: 'Error Retrieving Data!'})
//             })

//             axios.get('http://localhost:8080/api/v1/medicalstore/medicines/')
//             .then((response) => {
//                 console.log(response);
//                 this.setState({medicine: response.data})
        
//             })
//             .catch(error => {
//                 console.error(error);
//                 this.setState({errorMsg: 'Error Retrieving Data!'})
//             })    

//     }

//     delete(stockId){
//         axios.delete(`http://localhost:8080/api/v1/medicalstore/stocks/delete/${stockId}`)
//             .then((response) => {
//                 console.log(response);
                
//             })
//             .catch(error => {
//                 console.error(error);
//                 this.setState({errorMsg: 'Error Deleting Data!'})
//             })  
        
//     }
   

//     render() {
//         const{ stock, medicine, errorMsg } = this.state
//         return(
//             <div>
//                 <nav className="navbar navbar-expand-lg navbar-light bg-light fixed-top">
//                     <div className="container-fluid">
//                         <div className="collapse navbar-collapse" id="navbarNav">
//                             <ul className="navbar-nav">

//                                 <li className="nav-item">
//                                     <img src={logo} style={{height:'50px', width:'190px'}}/>
//                                 </li>

//                                 <li className="nav-item" style={{marginLeft:'5px'}}>
//                                     <a className="nav-link" href="/" to="/">Home</a>
//                                 </li>
                                
//                                 <li className="nav-item">
//                                     <a className="nav-link" to="/listOfStock">Contact</a>
//                                 </li>
// {/* 
//                                 <li className="nav-item" style={{float:'right', marginLeft:'800px', padding:'5px', height:'30px', width:'30px'}}>
//                                     <img src={customerlogin} /> &nbsp;
//                                 </li>
//                                 <li className="nav-item" style={{float:'right'}}>    
//                                     <a className="nav-link" to="">Logout</a>
//                                 </li> */}
//                             </ul>
//                         </div>
//                     </div>
//                 </nav>
//                 <div class="sidenav">
//                     <a href="/"> Home</a>
//                     <a href="/admin-list">Admins</a>
//                     <a href="/view-manufacturer">Manufacturers</a>
//                     <a href="/listOfStock">View Stock</a>
//                     <a href="/buy-medicine">Medicines</a>
//                     <a href="/add-manufacturer">Add Manufacturers</a>
//                     <a href="/registration">Add Admin</a>
//                     <a href="/add">Add Stock</a>
//                 </div>

//                 <div style={{marginTop:"70px", marginLeft:"300px"}}>
//                 <div class='container my-2' style={{backgroundColor:'', height:'80px', width:'100%', padding:'20px', borderRadius:'20px', verticalAlign:'middle'}}>
//                     <div style={{fontSize:'20px', float:'right', color:'#666565', marginRight:'15px', textAlign:'center'}}>List of stock</div>
//                     <Link class='rounded-pill' style={{fontSize:'20px', float:'left', color:'#666565', marginLeft:'15px', height:'50px', width:'120px', backgroundColor:'#3156A7', border:'none', color:'white', textAlign:"center"}} to="/add" >Add Stock</Link> 
//                     <Route exact path="/add">
//                         <AddStock></AddStock>
//                     </Route>
//                 </div>


//                 {   stock.length?
//                     stock.map( s =>
//                 <div class="card my-2 mx-3" style={{borderLeft:'5px solid #276A7B', borderRadius:'25px'}}>
//                     <div class="card-body">
//                     <img class="card-img-top" src={pic} alt="medical plus sign" style={{height:'100px', width:'100px', marginTop:'5px', marginBottom:'5px', float:'left'}}/>
//                   <div class='container'>
//                   <div class='row'>
//                         <div class='col-8'>
//                             <div class='row'>
//                                 <div style={{color:'#276A7B', marginLeft:'30px', fontFamily:'', fontSize:'50px', float:'left'}}>{s.medicineName}</div>
//                             </div>
//                             <div class='row'>
//                                 <div style={{color:'#999999', marginLeft:'30px', fontFamily:'', fontSize:'20px', float:'left', marginTop:'20px'}}> {s.sold} sold&nbsp; &nbsp; | &nbsp; &nbsp; {s.inStock}&nbsp;left in stock</div>
//                             </div>
//                         </div>
//                         <div class='col-4'>
//                             <div class='row'>
//                             <div class='col-lg'>
//                                 {/* <button class='rounded-pill' style={{ fontFamily:'', fontSize:'20px', border:'none', backgroundColor:'#36A592', height:'80px', width:'60px', marginTop:'15px', marginLeft:'0'}}></button>   */}
//                                 <button class='rounded-pill' style={{ fontFamily:'', fontSize:'20px', border:'none', backgroundColor:'#EC275F', height:'80px', width:'100px', marginTop:'15px', marginLeft:'10px', color:"white"}} onClick={this.delete.bind(this,s.stockId)}>Delete</button>      
//                             </div>
//                             <div class='col-sm'>
//                                 <div style={{color:'#ed9e4a', fontFamily:'', fontSize:'50px', float:'right', marginTop:'15px'}}>{s.costEach}&nbsp;$.</div>        
//                             </div>
//                             </div>
//                         </div>
//                   </div>
//                     </div>
//                     </div>
//                     </div>
//                     ):
//                     null
//                     }
//                     <div>
//                         { errorMsg.length? <div>{errorMsg}</div>: null}
//                     </div>
//                     </div>
//             </div>
//         )
//     }
// }

// export default ViewStock
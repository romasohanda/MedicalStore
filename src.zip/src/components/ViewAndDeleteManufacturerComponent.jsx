import React, { Component } from 'react'
import ManufacturerServices from '../services/ManufacturerServices'
import UpdateManufacturerComponent from './UpdateManufacturerComponent';
import { BrowserRouter as Router, Switch, Link, Route } from 'react-router-dom';


import pic from '../images/medical-plus.svg';
import best from '../images/best.png'
import adminimg from '../images/admin login.png';
import customerlogin from '../images/customer login.png';
import edit from '../images/edit.png'

import logo from '../images/logo medical.png';

class ViewAndDeleteManufacturerComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            manufacturer: []
        }
        this.addManufacturer = this.addManufacturer.bind(this);
        this.buyMedicine = this.buyMedicine.bind(this);
        this.deleteManufacturer = this.deleteManufacturer.bind(this);
    }

    deleteManufacturer(manufacturerId){
        ManufacturerServices.deleteManufacturer(manufacturerId).then( res => {
            this.setState({manufacturer: this.state.manufacturer.filter(manufacturers => manufacturers.manufacturerId !== manufacturerId)});
            alert("Manufacturer Deleted")
        });
    }
    buyMedicine(){
        this.props.history.push('/buy-medicine');
    }

    componentDidMount(){
        
                ManufacturerServices.getManufacturers().then((res) => {
                    this.setState({ manufacturer: res.data});
                });
    }

    addManufacturer(){
        this.props.history.push('/add-manufacturer');
    }

    updateManufacturer(){
        this.props.history.push('/update-manufacturer');
    }

    render() {
        return (
            <div>
                <nav className="navbar navbar-expand-lg navbar-light bg-light fixed-top">
                    <div className="container-fluid">
                        <div className="collapse navbar-collapse" id="navbarNav">
                            <ul className="navbar-nav">

                                <li className="nav-item">
                                    <img src={logo} style={{height:'50px', width:'190px'}}/>
                                </li>

                                <li className="nav-item" style={{marginLeft:'5px'}}>
                                    <a className="nav-link" href="/" to="/">Home</a>
                                </li>
                                
                                <li className="nav-item">
                                    <a className="nav-link">Contact</a>
                                </li>
{/* 
                                <li className="nav-item" style={{float:'right', marginLeft:'800px', padding:'5px', height:'30px', width:'30px'}}>
                                    <img src={customerlogin} /> &nbsp;
                                </li>
                                <li className="nav-item" style={{float:'right'}}>    
                                    <a className="nav-link" to="">Logout</a>
                                </li> */}
                            </ul>
                        </div>
                    </div>
                </nav>

                <div class="sidenav">
                    <a href="/"> Home</a>
                    <a href="/admin-list">Admins</a>
                    <a href="/view-manufacturer">Manufacturers</a>
                    <a href="/listOfStock">View Stock</a>
                    {/* <a href="/buy-medicine">Medicines</a> */}
                    <a href="/add-manufacturer">Add Manufacturers</a>
                    <a href="/registration">Add Admin</a>
                    <a href="/add">Add Stock</a>
                </div>

                <div id="back1" ></div>
                <div className="container"><br/>
                 <h2 id="list" className="text-left" style={{marginLeft:"250px"}}>List of Manufacturers</h2>

                 <div class='container my-2' id="update1"style={{backgroundColor:'', height:'80px', 
                 width:'100%', padding:'10px', borderRadius:'20px', verticalAlign:'middle'}}>
                    <button class='rounded-pill' style={{fontSize:'20px', float:'right', 
                    color:'#666565', marginRight:'15px', height:'50px', width:'90px', 
                    backgroundColor:'#3156A7', border:'none', color:'white', marginTop:'-60px'}} 
                    // to="/update-manufacturer" 
                    onClick={ () => this.updateManufacturer()} >
                    <img src={edit} style={{height:'30px', width:'30px', marginTop:'-6px', 
                    marginLeft:'5px'}}/>
                    </button> 
                    </div>
                 
                 {/* <div className = "row">
                    <button id="add" className="btn btn-primary" onClick={this.addManufacturer}>Add Manufacturer</button>
                 </div> */}
                 <button onClick={ () => this.buyMedicine()} 
                                                 className="btn btn-info">Buy</button><br/>
                 <div className = "row">
                        <table className = "table table-striped table-bordered"
                         style={{marginTop:'-80px', marginLeft:"250px"}}
                         >
                            <thead>
                                <tr>
                                    <th> ID</th>
                                    <th> Manufacturer Name</th>
                                    <th> Manufacturer mfg Licence Number</th>
                                    <th> Manufacturer Address</th>
                                    <th> Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.state.manufacturer.map(
                                        manufacturers => 
                                        <tr key = {manufacturers.manufacturerId}>
                                            <td> {manufacturers.manufacturerId} </td>
                                             <td> {manufacturers.manufacturerName} </td>   
                                             <td> {manufacturers.mfgLicence}</td>
                                             <td> {manufacturers.address}</td>
                                             <td>
                                                 
                                                 <button style={{marginLeft: "10px"}} onClick={ () => 
                                                    this.deleteManufacturer(manufacturers.manufacturerId)} 
                                                    type="button" className="btn btn-danger" data-toggle="modal" 
                                                    data-target="#centralModal">Delete </button>
                                             </td>
                                             
                                        </tr>
                                    )
                                }
                            </tbody>
                        </table>

                 </div>

            </div>
   
            </div>
        )
    }
}

export default ViewAndDeleteManufacturerComponent
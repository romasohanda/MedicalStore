
import React from 'react';
import './login.css'

import {toast} from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import service from '../service';

toast.configure();
class Login extends React.Component {
    constructor(props) {
        super(props);
        this.state={
            userId:'',
            password:'',
          userIdvalid:true,
            passwordvalid:true,
            userIdMessage:true,
            passwordMessage:true
        }
        this.handlesubmit=this.handlesubmit.bind(this);
        this.handlecheckPassword=this.handlecheckPassword.bind(this);
        this.handleLoginsubmit=this.handleLoginsubmit.bind(this);
        this.handleRegistersubmit=this.handleRegistersubmit.bind(this);
      }

      handleLoginsubmit=()=>{
       var userid=this.state.userId;
       var password=this.state.password;

          if(userid!==''&&password!=='')
          {
               service.getUser(userid,password).then(res=>{
               
                   console.log(res.data);
                   toast.success("user Registration Success",{
                    position: toast.POSITION.TOP_CENTER,
                    autoClose:false})
                  this.props.history.push("/welcome")
               }).catch(res=>{
                console.log(res.data);
                toast.error(" Enter correct data",{
                    position: toast.POSITION.TOP_CENTER,
                    autoClose:false})
                  
               })
           
          }else{
          if(this.state.userId===''){
              this.setState({userIdMessage:false})
          }
          if(this.state.password===''){
              this.setState({passwordMessage:false})
          }
          }

          console.log(this.state.userId);
          console.log(this.state.password);
        
      }
      handleRegistersubmit=()=>{
          this.props.history.push('/register')
      }
      handlesubmit=()=>{
          
this.props.history.push('/register');
      }
    handleUserId=(e)=>{
        this.setState({userId:e.target.value,userIdMessage:true});
        
    }
    handlePassword=(e)=>{
        this.setState({password:e.target.value,passwordMessage:true});
        console.log(this.state.password)
    }

    handlecheckUserId=(e)=>{
        if(e.target.value!==''){
        if (/^[A-Za-z]+$/.test(e.target.value)){
            this.setState({userIdvalid:true,userIdMessage:true});
           }else{
              this.setState({userIdvalid:false});
           }}else
           {
               this.setState({userIdMessage:false})
           }
    }
   handlecheckPassword=(e)=>{
       if(e.target.value!==''){
    if (/^(?=.*[\d])(?=.*[A-Z])(?=.*[a-z])(?=.*[!@#$%^&*])[\w!@#$%^&*]{8,}$/.test(e.target.value)){

        this.setState({passwordvalid:true,passwordMessage:true});
       }else{
          this.setState({passwordvalid:false});
       }}else{
           this.setState({passwordMessage:false});
       }
   }
  

    render() {
   
    const boolean=this.props.location.state;
   
    console.log(boolean);
 return(
      <div style={{ backgroundImage: 'url(${bimg})' , height:'600px', width:'1700px'}} >

    <div  >
     
     <div className="Login" style={{marginTop:"100px"}}>
     <div className="Login-box">
         <form >
         <h3> Login Form</h3>
         <div className='textbox'>
            
         <input type="userId" placeholder="User Id" name="User Id" onChange={this.handleUserId} onBlur={this.handlecheckUserId} value={this.state.userId} ></input>
         </div>
         <div style={{height:1}}>
        
         {this.state.userIdMessage?"":<b style={{color:'red',fontSize:10,marginRight:225,position:'relative',marginLeft:30,top:-16}}>Required</b>}
        
         {this.state.userIdvalid?"":<b style={{color:'red',fontSize:10,marginRight:10,position:'relative',marginLeft:-125,top:-10}}>Enter correct Id</b>}
         
         </div>



         <div className='textbox'>
            
         <input type="password" placeholder="Password" name="password" onChange={this.handlePassword} onBlur={this.handlecheckPassword} value={this.state.password}></input>
         </div>
         <div style={{height:1}}>
        
         {this.state.passwordMessage?"":<b style={{color:'red',fontSize:10,marginRight:225,position:'relative',marginLeft:30,top:-16}}>Required</b>}
        
         {this.state.passwordvalid?"":<b style={{color:'red',fontSize:10,marginRight:10,position:'relative',marginLeft:-100,top:-10}}>Enter password correctly</b>}
         
         </div>
         

         <div className="vi">
<button type="button"  style={{marginRight: 20, display: 'inline-block'}} className="but" onClick={this.handleRegistersubmit}>Sign Up</button>
<button type="button"  style={{marginLeft: 35,width: 100, display: 'inline-block'}} className="but2" onClick={this.handleLoginsubmit}>Sign IN</button></div>
      <br></br>  
</form>
</div>
     </div>
     </div>
     </div>
     
 )}
  }
  export default Login;
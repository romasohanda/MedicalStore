import React, { Component } from 'react';
import axios from 'axios';

import bimg from '../images/bimg.png'

import addmanufacturer from '../images/addmanufacturer.png'
import plusmanufacturer from '../images/plusmanufacturer.png'
import medicine from '../images/medicine.png'
import stockimg from '../images/stock.png'
import admins from '../images/admins.png'
import homeicon from '../images/homeicon.png'

class UpdateStock extends Component {
    constructor(props) {
        super(props);
        this.stockId = React.createRef();
        this.costEach = React.createRef();
        this.inStock = React.createRef();
        this.sold = React.createRef();
        this.medicineName = React.createRef();
        this.state = {
          errorMsg: ''
      }
    }
    componentDidMount() {
        
    }
    
  componentDidUpdate() {
      let check = this.props.returnedMessage.split(' ')
      if (check[0] === 'Successfully') {
          setTimeout(() => {
              this.props.history.push('/listOfStock')
          }, 2000)
      }
  }

     
    update(){
      let newStock = {
        stockId: this.stockId.current.value,
        costEach: this.costEach.current.value,
        inStock: this.inStock.current.value,
        sold: this.sold.current.value,
        medicineName: this.medicineName.current.value,
      }

        axios.put(`http://localhost:8000/api/v1/medicalstore/stocks/modify`,newStock)
                .then((response) => {
                    console.log(response);
                    alert("Sucessfully Updated")
                    
                })
                .catch(error => {
                    console.error(error);
                    this.setState({errorMsg: 'Error Updating Data!'})
                })  
    }

    cancel() {
        this.props.history.push('/listOfStock');
    }     
    render()  {
        return (


        <div>

{/* <div class="sidenav" style={{width:'160px',background: 'linear-gradient(111.14deg, rgba(255, 255, 255, 0.51) 3.08%, #76dbca 97.5%)', backdropFilter:'blur(10000%)'}}>
                    <a href="/" style={{fontSize:'13px', marginTop:'3px'}}> 
                    <img src={homeicon} style={{height:'30px', width:'30px', marginLeft:'40px'}}/><br/>
                    <div style={{fontSize:'13px', marginTop:'3px', marginLeft:'35px', color:'#276A7B'}}>Home</div></a>
                    <a href="/admin-list" style={{fontSize:'13px', marginTop:'3px'}}>
                    <img src={admins} style={{height:'30px', width:'30px', marginLeft:'40px'}}/><br/>
                    <div style={{fontSize:'13px', marginTop:'3px', marginLeft:'35px', color:'#276A7B'}}>Admins</div></a>
                    <a href="/view-manufacturer" style={{fontSize:'13px', marginTop:'3px'}}>
                    <img src={addmanufacturer} style={{height:'30px', width:'30px', marginLeft:'40px'}}/><br/>
                    <div style={{fontSize:'13px', marginTop:'3px', marginLeft:'20px', color:'#276A7B'}}>Manufacturers</div></a>
                    <a href="/listOfStock" style={{fontSize:'13px', marginTop:'3px'}}>
                    <img src={stockimg} style={{height:'30px', width:'30px', marginLeft:'40px'}}/><br/>
                    <div style={{fontSize:'13px', marginTop:'3px', marginLeft:'30px', color:'#276A7B'}}>View Stock</div></a>
                    <a href="/buy-medicine/:manufacturerId" style={{fontSize:'13px', marginTop:'3px'}}>
                    <img src={medicine} style={{height:'45px', width:'45px', marginLeft:'30px'}}/><br/>
                    <div style={{fontSize:'13px', marginTop:'3px', marginLeft:'30px', color:'#276A7B'}}>Medicine</div></a>
                    <a href="/add-manufacturer" style={{fontSize:'13px', marginTop:'3px'}}>
                    <img src={plusmanufacturer} style={{height:'20px', width:'20px', marginLeft:'20px'}}/>
                    <img src={addmanufacturer} style={{height:'30px', width:'30px'}}/><br/>
                    <div style={{fontSize:'13px', marginTop:'3px', color:'#276A7B'}}>Add Manufacturer</div></a>
                </div> */}

                  <div class="sidenav">
                     <a href="/"> Home</a>
                     <a href="/admin-list">Admins</a>
                     <a href="/view-manufacturer">Manufacturers</a>
                     <a href="/listOfStock">View Stock</a>
                     {/* <a href="/buy-medicine">Medicines</a> */}
                     <a href="/add-manufacturer">Add Manufacturers</a>
                     <a href="/registration">Add Admin</a>
                     <a href="/add">Add Stock</a>
                  </div>

              <div style={{ backgroundImage:`url(${bimg})`, height:'600px', width:'1700px'}}>
              <div className="container mx-5">
              <div className="row">
                <div className="col">
                <form style={{marginTop:'140px', marginLeft:'250px', width:'900px'}}>
                  <div className="mb-3 row">
                      <label htmlFor="name" className="col-sm-4 col-form-label">
                        <h5 style={{color:'#292E64'}}>Stock Id</h5>
                      </label>
                      <div className="col-sm-5">
                        <input
                          type="number"
                          className="form-control form-control-sm"
                          ref={this.stockId}
                          name="id"
                          required
                        />
                      </div>
                    </div>

                    <div className="mb-3 row">
                      <label htmlFor="name" className="col-sm-4 col-form-label">
                        <h5 style={{color:'#292E64'}}>Stock Name</h5>
                      </label>
                      <div className="col-sm-5">
                        <input
                          type="text"
                          className="form-control form-control-sm"
                          ref={this.medicineName}
                          name="name"
                          required
                        />
                      </div>
                    </div>
      
                    <div className="mb-3 row">
                      <label htmlFor="cost" className="col-sm-4 col-form-label">
                      <h5 style={{color:'#292E64'}}>Stock Cost</h5>
                      </label>
                      <div className="col-sm-5">
                        <input
                          type="number"
                          className="form-control form-control-sm"
                          ref={this.costEach}
                          name="cost"
                          required
                        />
                      </div>
                    </div>
      
      
                    <div className="mb-3 row">
                      <label htmlFor="instock" className="col-sm-4 col-form-label">
                      <h5 style={{color:'#292E64'}}> Quantity</h5>
                      </label>
                      <div className="col-sm-5">
                        <input
                          type="number"
                          className="form-control form-control-sm"
                          ref={this.inStock}
                          name="instock"
                          required
                        />
                      </div>
                    </div>
  
                    <div className="mb-3 row">
                      <label htmlFor="sold" className="col-sm-4 col-form-label">
                      <h5 style={{color:'#292E64'}}>Stock Sold</h5> 
                      </label>
                      <div className="col-sm-5">
                        <input
                          type="number"
                          className="form-control form-control-sm"
                          ref={this.sold}
                          name="sold"
                          required
                        />
                      </div>
                    </div>
  
                    <div className="row mt-3">
                      <div className="col">
                      <button
                          className="btn btn-md rounded-pill"
                          onClick={this.update.bind(this)}
                          style={{backgroundColor:'#EC275F', color:'white', width:'100px', float:'right'}}>
                          Update
                        </button>
                      </div>
                      <div className="col">
                        <button
                          className="btn btn-md btn-outline-success rounded-pill"
                          onClick={this.cancel.bind(this)}
                          style={{width:'100px', marginLeft:'60px',float:'left'}}>
                          Cancel
                        </button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
      
              <br></br>
              <br></br>
      
              <div className={(this.props.returnedMessage === '') ? '' : "alert"} role="alert">
                {this.props.returnedMessage}
              </div>
    
            </div>
            </div>
            </div>
          )
    }
            
}
export default UpdateStock;

// import React, { Component } from 'react';
// import axios from 'axios';

// import bimg from '../images/bimg.png'

// import addmanufacturer from '../images/addmanufacturer.png'
// import plusmanufacturer from '../images/plusmanufacturer.png'
// import medicine from '../images/medicine.png'
// import stockimg from '../images/stock.png'
// import admins from '../images/admins.png'
// import homeicon from '../images/homeicon.png'

// class UpdateStock extends Component {
//     constructor(props) {
//         super(props);
//         this.stockId = React.createRef();
//         this.costEach = React.createRef();
//         this.inStock = React.createRef();
//         this.sold = React.createRef();
//         this.medicineName = React.createRef();
//         this.state = {
//           errorMsg: ''
//       }
//     }
//     componentDidMount() {
        
//     }
    
//   componentDidUpdate() {
//       let check = this.props.returnedMessage.split(' ')
//       if (check[0] === 'Successfully') {
//           setTimeout(() => {
//               this.props.history.push('/listOfStock')
//           }, 2000)
//       }
//   }

     
//     update =(e) =>{
//       e.preventDefault(); 
//       let newStock = {
//         stockId: this.stockId.current.value,
//         costEach: this.costEach.current.value,
//         inStock: this.inStock.current.value,
//         sold: this.sold.current.value,
//         medicineName: this.medicineName.current.value,
//       }

//         axios.put(`http://localhost:8080/api/v1/medicalstore/stocks/modify`,newStock)
//                 .then((response) => {
//                     console.log(response);
                    
//                 })
//                 .catch(error => {
//                     console.error(error);
//                     this.setState({errorMsg: 'Error Updating Data!'})
//                 })  
//     }

//     cancel() {
//         this.props.history.push('/');
//     }     
//     render()  {
//         return (


//         <div>

// <div class="sidenav" style={{width:'160px',background: 'linear-gradient(111.14deg, rgba(255, 255, 255, 0.51) 3.08%, #76dbca 97.5%)', backdropFilter:'blur(10000%)'}}>
//                     <a href="/" style={{fontSize:'13px', marginTop:'3px'}}> 
//                     <img src={homeicon} style={{height:'30px', width:'30px', marginLeft:'40px'}}/><br/>
//                     <div style={{fontSize:'13px', marginTop:'3px', marginLeft:'35px', color:'#276A7B'}}>Home</div></a>
//                     <a href="/admin-list" style={{fontSize:'13px', marginTop:'3px'}}>
//                     <img src={admins} style={{height:'30px', width:'30px', marginLeft:'40px'}}/><br/>
//                     <div style={{fontSize:'13px', marginTop:'3px', marginLeft:'35px', color:'#276A7B'}}>Admins</div></a>
//                     <a href="/view-manufacturer" style={{fontSize:'13px', marginTop:'3px'}}>
//                     <img src={addmanufacturer} style={{height:'30px', width:'30px', marginLeft:'40px'}}/><br/>
//                     <div style={{fontSize:'13px', marginTop:'3px', marginLeft:'20px', color:'#276A7B'}}>Manufacturers</div></a>
//                     <a href="/listOfStock" style={{fontSize:'13px', marginTop:'3px'}}>
//                     <img src={stockimg} style={{height:'30px', width:'30px', marginLeft:'40px'}}/><br/>
//                     <div style={{fontSize:'13px', marginTop:'3px', marginLeft:'30px', color:'#276A7B'}}>View Stock</div></a>
//                     <a href="/buy-medicine/:manufacturerId" style={{fontSize:'13px', marginTop:'3px'}}>
//                     <img src={medicine} style={{height:'45px', width:'45px', marginLeft:'30px'}}/><br/>
//                     <div style={{fontSize:'13px', marginTop:'3px', marginLeft:'30px', color:'#276A7B'}}>Medicine</div></a>
//                     <a href="/add-manufacturer" style={{fontSize:'13px', marginTop:'3px'}}>
//                     <img src={plusmanufacturer} style={{height:'20px', width:'20px', marginLeft:'20px'}}/>
//                     <img src={addmanufacturer} style={{height:'30px', width:'30px'}}/><br/>
//                     <div style={{fontSize:'13px', marginTop:'3px', color:'#276A7B'}}>Add Manufacturer</div></a>
//                 </div>

//               <div style={{ backgroundImage:`url(${bimg})`, height:'600px', width:'1700px'}}>
//               <div className="container mx-5">
//               <div className="row">
//                 <div className="col">
//                 <form style={{marginTop:'140px', marginLeft:'250px', width:'900px'}}>
//                   <div className="mb-3 row">
//                       <label htmlFor="name" className="col-sm-4 col-form-label">
//                         <h5 style={{color:'#292E64'}}>Medicine Id</h5>
//                       </label>
//                       <div className="col-sm-5">
//                         <input
//                           type="number"
//                           className="form-control form-control-sm"
//                           ref={this.stockId}
//                           name="id"
//                           required
//                         />
//                       </div>
//                     </div>

//                     <div className="mb-3 row">
//                       <label htmlFor="name" className="col-sm-4 col-form-label">
//                         <h5 style={{color:'#292E64'}}>Medicine Name</h5>
//                       </label>
//                       <div className="col-sm-5">
//                         <input
//                           type="text"
//                           className="form-control form-control-sm"
//                           ref={this.medicineName}
//                           name="name"
//                           required
//                         />
//                       </div>
//                     </div>
      
//                     <div className="mb-3 row">
//                       <label htmlFor="cost" className="col-sm-4 col-form-label">
//                       <h5 style={{color:'#292E64'}}>Medicine Cost</h5>
//                       </label>
//                       <div className="col-sm-5">
//                         <input
//                           type="number"
//                           className="form-control form-control-sm"
//                           ref={this.costEach}
//                           name="cost"
//                           required
//                         />
//                       </div>
//                     </div>
      
      
//                     <div className="mb-3 row">
//                       <label htmlFor="instock" className="col-sm-4 col-form-label">
//                       <h5 style={{color:'#292E64'}}>Medicine In Stock</h5>
//                       </label>
//                       <div className="col-sm-5">
//                         <input
//                           type="number"
//                           className="form-control form-control-sm"
//                           ref={this.inStock}
//                           name="instock"
//                           required
//                         />
//                       </div>
//                     </div>
  
//                     <div className="mb-3 row">
//                       <label htmlFor="sold" className="col-sm-4 col-form-label">
//                       <h5 style={{color:'#292E64'}}>Medicine Sold</h5> 
//                       </label>
//                       <div className="col-sm-5">
//                         <input
//                           type="number"
//                           className="form-control form-control-sm"
//                           ref={this.sold}
//                           name="sold"
//                           required
//                         />
//                       </div>
//                     </div>
  
//                     <div className="row mt-3">
//                       <div className="col">
//                       <button
//                           className="btn btn-md rounded-pill"
//                           onClick={this.update.bind(this)}
//                           style={{backgroundColor:'#EC275F', color:'white', width:'100px', float:'right'}}>
//                           Update
//                         </button>
//                       </div>
//                       <div className="col">
//                         <button
//                           className="btn btn-md btn-outline-success rounded-pill"
//                           onClick={this.cancel.bind(this)}
//                           style={{width:'100px', marginLeft:'60px',float:'left'}}>
//                           Cancel
//                         </button>
//                       </div>
//                     </div>
//                   </form>
//                 </div>
//               </div>
      
//               <br></br>
//               <br></br>
      
//               <div className={(this.props.returnedMessage === '') ? '' : "alert"} role="alert">
//                 {this.props.returnedMessage}
//               </div>
    
//             </div>
//             </div>
//             </div>
//           )
//     }
            
// }
// export default UpdateStock;
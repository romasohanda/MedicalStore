import axios from 'axios';

const USER_API_BASE_URL = "http://localhost:8000/api/v1";
class Service {

    // getAdmin(emailId,password){
    //     return axios.get(ADMIN_API_BASE_URL+'/adminget/'+emailId+'/'+password);
    // }
    getUser(userId,password){
        return axios.get(USER_API_BASE_URL+'/Login/'+userId+'/'+password);
    }
    // getAdminUserId(id){
    //     return axios.get(ADMIN_API_BASE_URL+'/getuserid/'+id);
    // }

    // createAdminData(data){
    //     return axios.post(ADMIN_API_BASE_URL+'/adminregister', data);
    // }

    createUserData(data){
        return axios.post(USER_API_BASE_URL+'/userRegistration/createUserDetails', data);
    }

   
}

export default new Service()
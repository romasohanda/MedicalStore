import React, { Component } from 'react'

import adminimg from '../images/admin login.png';
import customerlogin from '../images/customer login.png';

import logo from '../images/logo medical.png';

class HeaderComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
                 
        }
    }

    render() {
        return (
            <div>
                <header>
                    {/* <nav id="nav" className="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
                    <div class="container">
  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#main_nav">
      <span class="navbar-toggler-icon"></span>
    </button>
  <div class="collapse navbar-collapse" id="main_nav">
                    <div><a href="" className="navbar-brand">Life Care Medical Store</a></div>
                    </div></div>
                    </nav> */}

<nav className="navbar navbar-expand-lg navbar-light bg-light fixed-top">
                    <div className="container-fluid">
                        <div className="collapse navbar-collapse" id="navbarNav">
                            <ul className="navbar-nav">

                                <li className="nav-item">
                                    <img src={logo} style={{height:'50px', width:'190px'}}/>
                                </li>

                                <li className="nav-item" style={{marginLeft:'5px'}}>
                                    <a className="nav-link" to="/">Home</a>
                                </li>
                                
                                <li className="nav-item">
                                    <a className="nav-link" to="/listOfStock">Contact</a>
                                </li>

                                <li className="nav-item" style={{float:'right', marginLeft:'800px', padding:'5px', height:'30px', width:'30px'}}>
                                    <img src={customerlogin} /> &nbsp;
                                </li>
                                <li className="nav-item" style={{float:'right'}}>    
                                    <a className="nav-link" to="">Logout</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
                </header>
            </div>
        )
    }
}

export default HeaderComponent
import React, { Component } from "react";
import AdminToAdminServices from "../services/AdminToAdminServices";
import img from '../images/img.png'
import pic from '../images/medical-plus.svg';
import best from '../images/best.png'
import adminimg from '../images/admin login.png';
import customerlogin from '../images/customer login.png';

import logo from '../images/logo medical.png';


class CreateAdminComponent extends Component {
    constructor(props) {
        super(props);

        this.state = {
           adminName:"",
           adminAge:"",
           adminJoiningDate:"",
           adminPassword:"",
           adminPhoneNum:"",

            adminNameError: "",
            adminAgeError: "",
            adminJoiningDateError: "",
            adminPasswordError: "",
            adminPhoneNumError: ""
           

        };

        this.ChangeadminNameHandler = this.ChangeadminNameHandler.bind(this)
        this.ChangeadminAgeHandler = this.ChangeadminAgeHandler.bind(this)
        this.ChangeadminJoiningDateHandler = this.ChangeadminJoiningDateHandler.bind(this)
        this.ChangeadminPasswordHandler = this.ChangeadminPasswordHandler.bind(this)
        this.ChangeadminPhoneNumHandler = this.ChangeadminPhoneNumHandler.bind(this)
        this.submitHandler = this.submitHandler.bind(this)
        //this.changeHandler =this.changeHandler.bind(this)
        //this.stopSubmission=this.stopSubmission.bind(this)
    }
   



    submitHandler = (e) => {
        e.preventDefault();
        let newAdmin = {
            adminName: this.state.adminName,
            adminAge: this.state.adminAge,
            adminJoiningDate: this.state.adminJoiningDate,
            adminPassword: this.state.adminPassword,
            adminPhoneNum: this.state.adminPhoneNum
           
        }
        const isValid = this.validate();
        console.log('newAdmin=>'+JSON.stringify(newAdmin));
        if (isValid) {
        AdminToAdminServices.createNewAdmin(newAdmin).then(response => {
            this.props.history.push('/admin-list');  
        });
    }
    else {
        alert("Form has errors");
    }
    }
      

    validate = () => {
        let adminNameError = "";
        let adminAgeError = "";
        let adminJoiningDateError = "";
        let adminPasswordError = "";
        let adminPhoneNumError = "";
       

     if (!this.state.adminName.match("[a-zA-Z]") || this.state.adminName.length < 3) {
           adminNameError = "Enter valid Username ";
       }
     if (!this.state.adminPhoneNum.match("[0-9]+" ) || this.state.adminPhoneNum.length < 10) {
          adminPhoneNumError = "please enter 10 digit mobile number";
         }

        if (!this.state.adminJoiningDate.match("[0-9]+")) {
            adminJoiningDateError = "Invalid Joining Date";
        }

        if (!this.state.adminAge.match("[1-9]") || this.state.adminAge.length < 2) {
            adminAgeError = "Enter valid age";
        }

   //"(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).8"
        if (!this.state.adminPassword.match("[A-Za-z0-9]+[!@#$%^&*]+[a-zA-Z0-9]*") || this.state.adminPassword.length < 5) {
            adminPasswordError = "Invalid password";
        }
        if (adminNameError || adminAgeError || adminJoiningDateError || adminPasswordError || adminPhoneNumError) {
            this.setState({
                adminNameError, adminAgeError, adminJoiningDateError, adminPasswordError, adminPhoneNumError
            });
            return false;
        }
        return true;
    };



    ChangeadminNameHandler = (e) => {
        this.setState({
               adminName: e.target.value
        }) 
    }

    ChangeadminAgeHandler = (e) => {
        this.setState({
            adminAge: e.target.value
        })
    }

    ChangeadminJoiningDateHandler = (e) => {
        this.setState({
            adminJoiningDate: e.target.value
        })
    }

    ChangeadminPasswordHandler = (e) => {
        this.setState({
            adminPassword: e.target.value
        })
    }

    ChangeadminPhoneNumHandler = (e) => {
        this.setState({
            adminPhoneNum: e.target.value
        })
    }

    

    cancel() {
        this.props.history.push('/admin-list');
    }
    //style={{ backgroundImage: `url(${backg})` } }

    render() {
        return (<div>

<nav className="navbar navbar-expand-lg navbar-light bg-light fixed-top">
                    <div className="container-fluid">
                        <div className="collapse navbar-collapse" id="navbarNav">
                            <ul className="navbar-nav">

                                <li className="nav-item">
                                    <img src={logo} style={{height:'50px', width:'190px'}}/>
                                </li>

                                <li className="nav-item" style={{marginLeft:'5px'}}>
                                    <a className="nav-link" href="/" to="/">Home</a>
                                </li>
                                
                                <li className="nav-item">
                                    <a className="nav-link">Contact</a>
                                </li>
{/* 
                                <li className="nav-item" style={{float:'right', marginLeft:'800px', padding:'5px', height:'30px', width:'30px'}}>
                                    <img src={customerlogin} /> &nbsp;
                                </li>
                                <li className="nav-item" style={{float:'right'}}>    
                                    <a className="nav-link" to="">Logout</a>
                                </li> */}
                            </ul>
                        </div>
                    </div>
                </nav>

                <div class="sidenav">
                    <a href="/"> Home</a>
                    <a href="/admin-list">Admins</a>
                    <a href="/view-manufacturer">Manufacturers</a>
                    <a href="/listOfStock">View Stock</a>
                    {/* <a href="/buy-medicine">Medicines</a> */}
                    <a href="/add-manufacturer">Add Manufacturers</a>
                    <a href="/registration">Add Admin</a>
                    <a href="/add">Add Stock</a>
                </div>

            <div style={{backgroundImage:`url(${img})`, height:"630px", width:"100%"}}>
                
                <div >
                    <div style={{paddingTop:"45px"}} >
                        <div id="reg" className="container" style={{marginLeft:"200px", marginTop:"50px"}}>
                            <div className="card col-md-8 offset-md-2 offset-med-3">

                                <h2>Registration Page</h2>

                                <form >
                                    <div className="form-group">
                                        <label>Username</label>
                                        <input
                                            type="text"
                                            value={this.state.adminName}
                                            name="adminName"
                                            placeholder="Enter your Full Name"
                                            className="form-control"
                                            onChange={this.ChangeadminNameHandler}
                                            //pattern="[a-zA-Z]{3,15}"
                                            required="required"
                                       
                                        />
                                        <div style={{ color: "red" }}>{this.state.adminNameError}</div>
                                    </div>



                                    <div className="form-group">
                                        <label>Mobile</label>
                                        <input
                                            type="number"
                                            value={this.state.adminPhoneNum}
                                            name="adminPhoneNum"
                                            placeholder="Mobile Number"
                                            className="form-control"
                                            onChange={this.ChangeadminPhoneNumHandler}
                                           // pattern="[7-9]{1}[0-9]{9}"
                                            required
                                         
                                        />
                                        <div style={{ color: "red" }}>{this.state.adminPhoneNumError}</div>

                                    </div>

                                    <div className="form-group">
                                        <label>Age</label>
                                        <input
                                            type="age"
                                            name="adminAge"
                                            placeholder="Enter Age"
                                            value={this.state.adminAge}
                                            className="form-control"
                                            onChange={this.ChangeadminAgeHandler}
                                           
                                            required
                                                   
                                        />
                                        <div style={{ color: "red" }}>{this.state.adminAgeError}</div>
                                    </div>

                                    <div className="form-group">
                                        <label>Joining date</label>
                                        <input
                                            type="date"
                                            name="adminJoiningDate"
                                            placeholder="Enter joinig Date"
                                            value={this.state.adminJoiningDate}
                                            className="form-control"
                                            onChange={this.ChangeadminJoiningDateHandler}
                                           // pattern="[[0-9]{2}/[0-9]{2}/[0-9]{4}]"
                                            required
                                      
                                        />
                                        <div style={{ color: "red" }}>{this.state.adminJoiningDateError}</div>

                                    </div>


                                   



                                    <div className="form-group">
                                        <label>Password</label>
                                        <input
                                            type="password"
                                            name="adminPassword"
                                            placeholder="Enter password"
                                            value={this.state.adminPassword}
                                            className="form-control"
                                            onChange={this.ChangeadminPasswordHandler}
                                          //  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
                                            required
                                        
                                        />
                                        <div style={{ color: "red" }}>{this.state.adminPasswordError}</div>

                                    </div>

                                    <div className="form-group">
                                        <button className="btn btn-success" onClick={this.submitHandler}>Register</button>
                                        <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{ marginLeft: "10px" }}>Cancel</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div  className="form-group"></div>
                </div>
            </div>
            </div>
        );
    }
}

export default CreateAdminComponent;
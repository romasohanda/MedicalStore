import React from 'react';
import { BrowserRouter as Router, Switch, Link, Route } from 'react-router-dom';
import ViewStock from './ViewStock';
import AddStock from './AddStock';
import Home from './Home'

import adminimg from '../images/admin login.png';
import customerlogin from '../images/customer login.png';

import logo from '../images/logo medical.png';

export function ReactRouter() {
    return (
        <Router>
            <div>
                {/* <nav className="navbar navbar-expand-lg navbar-light bg-light">
                    <div className="container-fluid">
                        <div className="collapse navbar-collapse" id="navbarNav">
                            <ul className="navbar-nav">

                                <li className="nav-item">
                                    <img src={logo} style={{height:'50px', width:'190px'}}/>
                                </li>

                                <li className="nav-item" style={{marginLeft:'5px'}}>
                                    <Link className="nav-link" to="/" >Home</Link>
                                </li>
                                
                                <li className="nav-item">
                                    <Link className="nav-link" to="/listOfStock">List</Link>
                                </li>
                               
                                <li className="nav-item">
                                    <Link className="nav-link" to="/add">Add</Link>
                                </li>

                                <li className="nav-item" style={{float:'right', marginLeft:'500px', padding:'5px', height:'30px', width:'30px'}}>
                                    <img src={adminimg} /> &nbsp;
                                </li>
                                <li className="nav-item" style={{float:'right'}}>    
                                    <Link className="nav-link" to="">Admin Login &nbsp;</Link>
                                </li>
                                <li className="nav-item" style={{float:'right', padding:'5px', height:'30px', width:'30px'}}>
                                    <img src={customerlogin} /> &nbsp;
                                </li>
                                <li className="nav-item" style={{float:'right'}}>    
                                    <Link className="nav-link" to="">Customer Login</Link>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav> */}

                {/* A <Switch> looks through its children <Route>s and
renders the first one that matches the current URL. */}
                <Switch>
                    <Route exact path="/listOfStock">
                        <ViewStock></ViewStock>
                    </Route>
                    <Route exact path="/add">
                        <AddStock></AddStock>
                    </Route>
                    <Route exact path="/">
                        <Home></Home>
                    </Route>
                </Switch>
            </div>
        </Router>
    )
}

export default ReactRouter

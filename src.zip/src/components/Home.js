import React, { Component } from 'react';

import img from '../images/medical shop banner.png';
import pills from '../images/pills.svg';
import best from '../images/best.png';
import germs from '../images/germs.png';

import adminimg from '../images/admin login.png';
import customerlogin from '../images/customer login.png';

import logo from '../images/logo medical.png';

class Home extends Component {
   
    render() {
        return (
            <div>
                <nav className="navbar navbar-expand-lg navbar-light bg-light fixed-top">
                    <div className="container-fluid">
                        <div className="collapse navbar-collapse" id="navbarNav">
                            <ul className="navbar-nav">

                                <li className="nav-item">
                                    <img src={logo} style={{height:'50px', width:'190px'}}/>
                                </li>

                                <li className="nav-item" style={{marginLeft:'5px'}}>
                                    <a className="nav-link" href="/" to="/">Home</a>
                                </li>
                                
                                <li className="nav-item">
                                    <a className="nav-link" href="/admin-list" to="/listOfStock">Admin</a>
                                </li>

                                <li className="nav-item">
                                    <a className="nav-link" href="/view-manufacturer" to="/listOfStock">Manufacturer</a>
                                </li>

                                <li className="nav-item">
                                    <a className="nav-link" href="/login" to="/listOfStock">Customer</a>
                                </li>

                                <li className="nav-item">
                                    <a className="nav-link" href="/listOfStock" to="/listOfStock">Stock</a>
                                </li>
                               
                                {/* <li className="nav-item" style={{float:'right', marginLeft:'300px', padding:'5px', height:'30px', width:'30px'}}>
                                    <img src={adminimg} /> &nbsp;
                                </li>
                                <li className="nav-item" style={{float:'right'}}>    
                                    <a className="nav-link" to="">Admin Login &nbsp;</a>
                                </li>
                                <li className="nav-item" style={{float:'right', padding:'5px', height:'30px', width:'30px'}}>
                                    <img src={customerlogin} /> &nbsp;
                                </li>
                                <li className="nav-item" style={{float:'right'}}>    
                                    <a className="nav-link" to="">Customer Login</a>
                                </li> */}
                            </ul>
                        </div>
                    </div>
                </nav>
                
                    <img src={img} style={{borderRadius:'50px', padding:'30px'}}/>
                
                
                    <h1 style={{color:'#292E64' }}>Everything you need to know about us....</h1>

                <div class='row'>
                    <div class='col'>
                        <div class="card" style={{width:'20rem', padding:'5px', marginLeft:'90px', marginTop:'20px', marginBottom:'20px', backgroundColor:'#9BB5C4', borderRadius:'30px'}}>
                        <img class="card-img-top" src={pills} alt="Card image cap" style={{height:'270px'}}/>
                        <div class="card-body">
                            <h5 class="card-title" style={{color:'white', textAlign:'center'}}>Save upto 75% on your pills</h5>
                            <p class="card-text" style={{color:'white', textAlign:'center'}}>Stop paying too much for your prescriptions and get best unlimited offers.</p>
                        </div>
                        </div>
                    </div>
                    <div class='col'>
                        <div class="card" style={{width:'20rem', padding:'5px', marginLeft:'45px', marginTop:'20px', marginBottom:'20px', backgroundColor:'#e09ba1', borderRadius:'30px'}}>
                        <img class="card-img-top" src={germs} alt="Card image cap" style={{height:'270px'}}/>
                        <div class="card-body">
                            <h5 class="card-title" style={{color:'white', textAlign:'center'}}>Free from viruses or bacteria</h5>
                            <p class="card-text" style={{color:'white', textAlign:'center'}}>We care for your health and take precautions while handling your medicines.</p>
                        </div>
                        </div>
                    </div>
                    <div class='col'>
                        <div class="card" style={{width:'20rem', padding:'5px', marginRight:'60px', marginTop:'20px', marginBottom:'20px', backgroundColor:'#79bad4', borderRadius:'30px'}}>
                        <img class="card-img-top" src={best} alt="Card image cap" style={{height:'270px'}}/>
                        <div class="card-body">
                            <h5 class="card-title" style={{color:'white', textAlign:'center'}}>We offer best</h5>
                            <p class="card-text" style={{color:'white', textAlign:'center'}}>Get unlimited access to the medicines from top rated companies with reasonable price.</p>
                        </div>
                        </div>
                    </div>
                </div>
                    

                    
            </div>
        );
    }
}

export default Home;
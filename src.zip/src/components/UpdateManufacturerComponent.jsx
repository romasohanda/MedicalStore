import React, { Component } from 'react';
import ManufacturerServices from '../services/ManufacturerServices'
import axios from 'axios';

import bimg from '../images/bimg.png'

import addmanufacturer from '../images/addmanufacturer.png'
import plusmanufacturer from '../images/plusmanufacturer.png'
import medicine from '../images/medicine.png'
import stockimg from '../images/stock.png'
import admins from '../images/admins.png'
import homeicon from '../images/homeicon.png'
import logo from '../images/logo medical.png';

class UpdateManufacturerComponent extends Component {
    constructor(props) {
        super(props);
        this.manufacturerId = React.createRef();
        this.manufacturerName = React.createRef();
        this.mfgLicence = React.createRef();
        this.address = React.createRef();
        this.state = {
          errorMsg: ''
      }

    this.changeIdHandler=this.changeIdHandler.bind(this);
    this.changeNameHandler=this.changeNameHandler.bind(this);
    this.changeLicenceHandler=this.changeLicenceHandler.bind(this);
    this.changeAddressHandler=this.changeAddressHandler.bind(this);
    this.editManufacturer=this.editManufacturer.bind(this);

    }

    componentDidMount() {
        
    }

    changeIdHandler=(event)=>{
      this.setState({manufacturerId: event.target.value});
  }

    changeNameHandler=(event)=>{
              this.setState({manufacturerName: event.target.value});
          }
      
    changeLicenceHandler=(event)=>{
              this.setState({mfgLicence: event.target.value});
          }
      
    changeAddressHandler=(event)=>{
              this.setState({address: event.target.value});
          }
      
    
  // componentDidUpdate() {
  //     let check = this.props.returnedMessage.split(' ')
  //     if (check[0] === 'Successfully') {
  //         setTimeout(() => {
  //             this.props.history.push('/view-manufacturer')
  //         }, 2000)
  //     }
  // }

  editManufacturer=(e)=>{
            e.preventDefault();
            let manu={ 
              manufacturerId: this.state.manufacturerId,
              manufacturerName: this.state.manufacturerName, 
              mfgLicence: this.state.mfgLicence, 
              address: this.state.address};
            console.log('manu =>' + JSON.stringify(manu));
    
            ManufacturerServices.updateManufacturer(manu).then(res =>{
              console.log(res);
                    alert("Successfully Updated")
                this.props.history.push('/view-manufacturer');
            })
            .catch(error => {
              console.error(error);
              this.setState({errorMsg: 'Error Updating Data!'})
          })  
        }
     
    // update(){
    //   let newManufacturer = {
    //     manufacturerId: this.manufacturerId.current.value,
    //     manufacturerName: this.manufacturerName.current.value,
    //     mfgLicence: this.mfgLicence.current.value,
    //     address: this.address.current.value
    //   }

    //     axios.put(`http://localhost:8080/api/v1/medicalstore/manufacturer/update_manufacturer`,
    //     newManufacturer)
    //             .then((response) => {
    //                 console.log(response);
    //                 alert("Sucessfully Updated")
                    
    //             })
    //             .catch(error => {
    //                 console.error(error);
    //                 this.setState({errorMsg: 'Error Updating Data!'})
    //             })  
    // }

    cancel() {
        this.props.history.push('/view-manufacturer');
    }     
    render()  {
        return (


        <div>
           <nav className="navbar navbar-expand-lg navbar-light bg-light fixed-top">
                    <div className="container-fluid">
                        <div className="collapse navbar-collapse" id="navbarNav">
                            <ul className="navbar-nav">

                                <li className="nav-item">
                                    <img src={logo} style={{height:'50px', width:'190px'}}/>
                                </li>

                                <li className="nav-item" style={{marginLeft:'5px'}}>
                                    <a className="nav-link" href="/" to="/">Home</a>
                                </li>
                                
                                <li className="nav-item">
                                    <a className="nav-link">Contact</a>
                                </li>
{/* 
                                <li className="nav-item" style={{float:'right', marginLeft:'800px', padding:'5px', height:'30px', width:'30px'}}>
                                    <img src={customerlogin} /> &nbsp;
                                </li>
                                <li className="nav-item" style={{float:'right'}}>    
                                    <a className="nav-link" to="">Logout</a>
                                </li> */}
                            </ul>
                        </div>
                    </div>
                </nav>

                  <div class="sidenav">
                     <a href="/"> Home</a>
                     <a href="/admin-list">Admins</a>
                     <a href="/view-manufacturer">Manufacturers</a>
                     <a href="/listOfStock">View Stock</a>
                     {/* <a href="/buy-medicine">Medicines</a> */}
                     <a href="/add-manufacturer">Add Manufacturers</a>
                     <a href="/registration">Add Admin</a>
                     <a href="/add">Add Stock</a>
                  </div>

                  <div><br/><br/>
                  <div  id="back2">
                 <div className="container">
                     <div className="row">
                         <div className="card col-md-6 offset-md-3"  id="updateComponent">
                             <h2 className="text-center">Update Manufacturer Details</h2>
                             <div className="card-body">
                                 <form>
                                     <div className="form-group">

                                        <label>Manufacturer's ID</label>
                                        <input placeholder="Enter ID of the Manufacturer" 
                                        name="name" className="form-control" value={this.state.manufacturerId} 
                                        onChange={this.changeIdHandler}></input><br></br>

                                         <label>Manufacturer's Name</label>
                                         <input placeholder="Enter Name of the Manufacturer" 
                                        name="name" className="form-control" value={this.state.manufacturerName} 
                                        onChange={this.changeNameHandler}></input><br></br>
                                        
                                        <label>Manufacturer's mfg Licence number</label>
                                        <input placeholder="Enter mfg licence number" 
                                        name="name" className="form-control" value={this.state.mfgLicence} 
                                        onChange={this.changeLicenceHandler}></input><br></br>
                                        
                                        <label>Manufacturer's address</label>
                                        <input placeholder="Enter address of the Manufacturer" 
                                        name="name" className="form-control" value={this.state.address} 
                                        onChange={this.changeAddressHandler}></input>
                                    </div>
                                    <button className="btn btn-primary" onClick={this.editManufacturer}>Update Changes</button>
                                    <button style={{marginLeft: "10px"}} className="btn btn-danger" onClick={this.cancel.bind(this)}>Cancel</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
      
              <br></br>
              <br></br>
      
              <div className={(this.props.returnedMessage === '') ? '' : "alert"} role="alert">
                {this.props.returnedMessage}
              </div>
    
            </div>
            </div>
          )
    }
            
}
export default UpdateManufacturerComponent;

// import React, { Component } from 'react';
// import ManufacturerServices from '../services/ManufacturerServices';

// class UpdateManufacturerComponent extends Component {
//     constructor(props){
//         super(props)
//         this.state={
//             manufacturerName:'',
//             mfgLicence:'',
//             address:''
//         }
//         this.changeNameHandler=this.changeNameHandler.bind(this);
//         this.changeLicenceHandler=this.changeLicenceHandler.bind(this);
//         this.changeAddressHandler=this.changeAddressHandler.bind(this);
//         this.editManufacturer=this.editManufacturer.bind(this);
//     }

//     componentDidMount(){
//         ManufacturerServices.getManufacturerById(this.state.manufacturerId).then((res)=>{
//             let manu= res.data;
//             this.setState({
//                 manufacturerName: manu.manufacturerName,
//                 mfgLicence: manu.mfgLicence,
//                 address: manu.address
//             });
//         });
//     }

//     changeNameHandler=(event)=>{
//         this.setState({manufacturerName: event.target.value});
//     }

//     changeLicenceHandler=(event)=>{
//         this.setState({mfgLicence: event.target.value});
//     }

//     changeAddressHandler=(event)=>{
//         this.setState({address: event.target.value});
//     }

//     cancel(){
//         this.props.history.push('/view-manufacturer');
//     }

//     editManufacturer=(e)=>{
//         e.preventDefault();
//         let manu={manufacturerName: this.state.manufacturerName, mfgLicence: this.state.mfgLicence, address: this.state.address};
//         console.log('manu =>' + JSON.stringify(manu));

//         ManufacturerServices.updateManufacturer(manu, this.state.manufacturerId).then(res =>{
//             this.props.history.push('/view-manufacturer');
//         })
//     }

//     render() {
//         return (
//             <div><br/><br/>
//                 <div className="container">
//                     <div className="row">
//                         <div className="card col-md-6 offset-md-3">
//                             {/* <h2 className="text-center">Update Manufacturer Details</h2> */}
//                             <div className="card-body">
//                                 <form>
//                                     <div className="form-group">
//                                         <label>Manufacturer's Name</label>
//                                         <input placeholder="Enter Name of the Manufacturer" 
//                                         name="name" className="form-control" value={this.state.manufacturerName} 
//                                         onChange={this.changeNameHandler}></input><br></br>
                                        
//                                         <label>Manufacturer's mfg Licence number</label>
//                                         <input placeholder="Enter mfg licence number" 
//                                         name="name" className="form-control" value={this.state.mfgLicence} 
//                                         onChange={this.changeLicenceHandler}></input><br></br>
                                        
//                                         <label>Manufacturer's address</label>
//                                         <input placeholder="Enter address of the Manufacturer" 
//                                         name="name" className="form-control" value={this.state.address} 
//                                         onChange={this.changeAddressHandler}></input>
//                                     </div>
//                                     <button className="btn btn-primary" onClick={this.editManufacturer}>Update Changes</button>
//                                     <button style={{marginLeft: "10px"}} className="btn btn-danger" onClick={this.cancel.bind(this)}>Cancel</button>
//                                 </form>
//                             </div>
//                         </div>
//                     </div>
//                 </div>
//             </div>
//         );
//     }
// }

// export default UpdateManufacturerComponent;

// import React, { Component } from 'react'
// import ManufacturerServices from '../services/ManufacturerServices';

// class UpdateManufacturerComponent extends Component {
//     constructor(props) {
//         super(props)

//         this.state = {
//             id: this.props.match.params.id,
//             manufacturerName: '',
//             mfgLicence: '',
//             address: ''
//         }
//         this.changeNameHandler = this.changeNameHandler.bind(this);
//         this.changeLicenceHandler = this.changeLicenceHandler.bind(this);
//         this.changeAddressHandler = this.changeAddressHandler.bind(this);
//         this.editManufacturer = this.editManufacturer.bind(this);
//     }

//     componentDidMount(){
//         ManufacturerServices.getManufacturerById(this.state.manufacturerId).then( (res) =>{
//             let manufacturer = res.data;
//             this.setState({manufacturerName: manufacturer.manufacturerName,
//                 mfgLicence: manufacturer.mfgLicence,
//                 address : manufacturer.address
//             });
//         });
//     }

//     editManufacturer = (e) => {
//         e.preventDefault();
//         let manu = {manufacturerName: this.state.manufacturerName, mfgLicence: this.state.mfgLicence, address: this.state.address};
//         console.log('manu => ' + JSON.stringify(manu));
//         console.log('manuId => ' + JSON.stringify(this.state.manufacturerId));
//         ManufacturerServices.updateManufacturer(manu, this.state.manufacturerId).then( res => {
//             this.props.history.push('/view-manufacturer');
//         });
//     }
    
//     changeNameHandler= (event) => {
//         this.setState({manufacturertName: event.target.value});
//     }

//     changeLicenceHandler= (event) => {
//         this.setState({mfgLicence: event.target.value});
//     }

//     changeAddressHandler= (event) => {
//         this.setState({address: event.target.value});
//     }

//     cancel(){
//         this.props.history.push('/view-manufacturer');
//     }

//     render() {
//         return (
//             <div>
//                 <br></br><br/>
//                    <div className = "container">
//                         <div className = "row">
//                             <div className = "card col-md-6 offset-md-3 offset-md-3">
//                                 <h3 className="text-center">Update Manufacturer</h3>
//                                 <div className = "card-body">
//                                     <form>
//                                         <div className = "form-group">
//                                             <label> Manufacturer's Name: </label>
//                                             <input placeholder="Enter Manufacturer Name" name="name" className="form-control" 
//                                                 value={this.state.manufacturerName} onChange={this.changeNameHandler}/>
//                                         </div><br/>
//                                         <div className = "form-group">
//                                             <label> Manufacturer's mfg Licence number: </label>
//                                             <input placeholder="Enter mfg Licence number" name="licence" className="form-control" 
//                                                 value={this.state.mfgLicence} onChange={this.changeLicenceHandler}/>
//                                         </div><br/>
//                                         <div className = "form-group">
//                                             <label> Address: </label>
//                                             <input placeholder="Enter Address" name="address" className="form-control" 
//                                                 value={this.state.address} onChange={this.changeAddressHandler}/>
//                                         </div>

//                                         <button className="btn btn-primary" onClick={this.editManufacturer}>Update Changes</button>
//                                         <button style={{marginLeft: "10px"}} className="btn btn-danger" onClick={this.cancel.bind(this)}>Cancel</button>
//                                     </form>
//                                 </div>
//                             </div>
//                         </div>

//                    </div>
//             </div>
//         )
//     }
// }

// export default UpdateManufacturerComponent